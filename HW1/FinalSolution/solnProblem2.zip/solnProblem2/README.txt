Instruction for evaluating:

Open shell and launch ampl
type " include runcplex.run; "
hit enter
result will be generated.