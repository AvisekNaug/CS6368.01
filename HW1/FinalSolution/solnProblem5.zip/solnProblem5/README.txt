Instruction for evaluating:

Open shell and launch ampl
type " include runqpcplex.run; "
hit enter
result will be generated.